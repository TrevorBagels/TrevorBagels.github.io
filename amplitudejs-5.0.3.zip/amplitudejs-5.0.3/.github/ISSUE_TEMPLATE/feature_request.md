---
name: "\U0001F680 Feature Request"
about: Suggest a new feature ✨
labels: feature-request
assignees: ''

---
<!-- 🤵 Looking for professional support? Guaranteed response times next business day. Learn more here: https://521d.me/amplitudejs-professional-support -->

## Why should this feature be implemented?
<!--  What problem does it solve? -->

## Feature Description
<!-- Describe your feature request in detail -->
<!-- Please provide any code examples or screenshots of what this feature would look like -->
<!-- Are there any drawbacks? Will this break anything for existing users? -->
